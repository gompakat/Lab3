# Elad Tal and Aditya Gompa
# Lab 02
# The Dollar class that extends the abstract Currency Class

from currency import Currency

class Dollar(Currency):
  
  def add(self, other):
    if isinstance(other, Dollar):
      self.setValue(other.getValue() + self.getValue())
    else:
      print("Invalid Addition")

  def subtract(self, other):
    if isinstance(other, Dollar):
      if self.getValue() - other.getValue() >= 0:
        self.setValue(self.getValue() - other.getValue())
      else:
        print("Invalid Subtraction")
    else:
      print("Invalid Subtraction")

  def isEqual(self, other):
    if isinstance(other, Dollar):
      return self.getValue() == other.getValue()
    else:
      print("Invalid Equality Check")

  def isGreater(self, other):
    if isinstance(other, Dollar):
      return self.getValue() > other.getValue()
    else:
      print("Invalid Comparison")

  def toString(self):
    return f"{self.getValue():.2f} Dollar"