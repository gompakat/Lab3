# Elad Tal and Aditya Gompa
# Lab 03
# The LinkNode Class that handles a data set of currency objects

class LinkNode:

#Pre: d (data) for the linknode and n (next) is the next linknode 
#Post: a new linknode object with specified data and next nodes
    def __init__(self, d, n):
        self.data = d
        self.next = n

#Pre: 
#Post: The linknode object is destructed 
    def destruct(self):
        del self