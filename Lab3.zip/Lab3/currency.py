# Elad Tal and Aditya Gompa
# Lab 02
# The Currency class will be the abstract base class for new currencies

import copy

from abc import ABC, abstractmethod

class Currency(ABC):

  def __init__(self, d):
    self.wholePart = d
    self.fractionalPart = self.wholePart / 100

  def setValue(self, d):
    if d < 0:
      d = 0
    self.wholePart = d
    self.fractionalPart = self.wholePart / 100

  def getValue(self):
    return self.wholePart

  def Copy(self, other):
    other.setValue(self.getValue())

  def copy(self):
      return copy.copy(self)

  def Destruct(self):
    del self

# Adds The Value Of Another Currency Object From The Current One
# Pre: Self and other
# Post: Increases the value of the currency object
# Return: 
  @abstractmethod
  def add(self, other):
    pass

# Subtracts The Value Of Another Currency Object From The Current One
# Pre: Self and Other object
# Post: Decreases the value of the currency object
# Return: 
  @abstractmethod
  def subtract(self, other):
    pass

# Check if values of both objects are equal to each other
# Pre: Self and other
# Post: 
# Return: The value of the object
  @abstractmethod
  def isEqual(self, other):
    pass
    
# Checks if current object is greater than the other object
# Pre: Self and Other object
# Post: 
# Return: True if the current object is greater and false otherwise
  @abstractmethod
  def isGreater(self, other):
    pass

# Formats the currency object into a string
# Pre: Self and Other Object
# Post: 
# Return: A string representing the currency object
  @abstractmethod
  def toString(self):
    pass