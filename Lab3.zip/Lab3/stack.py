# Elad Tal and Aditya Gompa
# Lab 03
# The Stack Class is derived from the SinglyLinkedList class and handles a data set of currency objects with no additional attributes and the usual stack methods

from singlylinkedlist import SinglyLinkedList
from currency import Currency

class Stack(SinglyLinkedList):

    #Pre: 
    #Post: new stack object created by initializing SinglyLinkedList
    def __init__(self):
        super().__init__()

    #Pre: c (currency): the currency object to be pushed
    #Post: the currency object is pushed to hte top of the stack
    def push(self, c):
        super().addCurrency(c, 0)

    #Pre: 
    #Post: the currency object is removed from the top of the stack
    def pop(self):
        if self.count == 0:
            raise IndexError("Index out of bounds")
        c = super().getCurrency(super().countCurrency()-1)
        super().removeCurrency(c.data)
        return c
    
    def peek(self):
        return super().getCurrency(0).data.copy()
    
    def printStack(self):
        result = "Stack: \n"
        cur_node = self.start
        while cur_node != None:
            result += "    " + cur_node.data.toString() + "\n"
            cur_node = cur_node.next
        return result.rstrip()

    #Pre:
    #Post: the stack is destroyed and the data is removed
    def destroyStack(self):
        super().destroyList()

    def destroyList(self):
        raise NotImplementedError("Stack does not support destroyList")

    def addCurrency(self, curr, i):
        raise NotImplementedError("Stack does not support addCurrency")

    def removeCurrency(self, i):
        raise NotImplementedError("Stack does not support removeCurrency")

    def findCurrency(self, c):
        raise NotImplementedError("Stack does not support findCurrency")
        
    def getCurrency(self, i):
        raise NotImplementedError("Stack does not support getCurrency")
        
    def printList(self):
        raise NotImplementedError("Stack does not support printList")
        
    def isListEmpty(self):
        raise NotImplementedError("Stack does not support isListEmpty")
        
    def countCurrency(self):
        raise NotImplementedError("Stack does not support countCurrency")
