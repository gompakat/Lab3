# Elad Tal and Aditya Gompa
# Lab 03
# The main class for running the program

from stack import Stack
from currency_queue import Queue
from singlylinkedlist import SinglyLinkedList
from currency import Currency
from dollar import Dollar

def main():
    print("Welcome to the Currency Data Structure Program!\nBy Elad Tal and Aditya Gompa")
    dollar_values = [57.12, 23.44, 87.43, 68.99, 111.22, 44.55, 77.77, 18.36, 543.21, 20.21, 345.67, 36.18, 48.48, 101.00, 11.00, 21.00, 51.00, 1.00, 251.00, 151.00]
    currency_array = []
    for value in dollar_values:
        currency_array.append(Dollar(value))
    
    # Starting Linked List Tasks
    linked_list = SinglyLinkedList()
    for c in currency_array[:7]:
        linked_list.addCurrency(c, 0)
    
    print(f"Index of 87.43 is {linked_list.findCurrency(Dollar(87.43))}")
    print(f"Index of 44.56 is {linked_list.findCurrency(Dollar(44.56))}")

    linked_list.removeCurrency(Dollar(111.22))
    linked_list.removeCurrency(2)

    print(linked_list.printList())

    for i in range(9, 13):
        linked_list.addCurrency(currency_array[i], i % 5)
    
    linked_list.removeCurrency(linked_list.countCurrency() % 6)
    linked_list.removeCurrency(linked_list.countCurrency() // 7)
    
    print(linked_list.printList())
    
    #Starting Stack Tasks
    stack = Stack()

    for i in range(13, 20):
        stack.push(currency_array[i])
        
    print("Front Of Stack:",stack.peek().toString())

    for i in range(3):
        stack.pop()

    print(stack.printStack())

    for i in range(5):
        stack.push(currency_array[i])

    stack.pop()
    stack.pop()

    print(stack.printStack())
    
    #Starting Queue Tasks
    queue = Queue()
    
    for i in range(5, 20, 2):
        queue.enqueue(currency_array[i])
    
    print("Front Of Queue:", queue.peekFront().toString())
    print("Rear Of Queue:", queue.peekRear().toString())
    
    queue.dequeue()
    queue.dequeue()
    
    print(queue.printQueue())

    for i in range(10, 15):
        queue.enqueue(currency_array[i])

    for i in range(3):
        queue.dequeue()

    print(queue.printQueue())
    
    print("Thank you for using the Currency Data Structure Program!")

    linked_list.destroyList()
    stack.destroyStack()
    queue.destroyQueue()

main()