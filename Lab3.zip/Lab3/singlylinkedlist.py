# Elad Tal and Aditya Gompa
# Lab 03
# The SinglyLinkedList Class that handles a data set of currency objects

from currency import Currency
from linknode import LinkNode

class SinglyLinkedList:
    
    #Pre:
    #Post: singlylinkedlist object created with count set to 0 and start and end set to None
    def __init__(self):
        self.count = 0
        self.start = None
        self.end = None

    #Pre: 
    #Post: new singlylinkedlist object is created and returned
    @staticmethod
    def createList():
        return SinglyLinkedList()

    #Pre: 
    #Post: singlylinkedlist object is destroyed
    def destruct(self):
        del self
    
    #Pre:
    #Post: linkedlist is destructed and all data is removed
    def destroyList(self):
        if self.count > 0:
            cur_node = self.start
            while cur_node != None:
                next_node = cur_node.next
                cur_node.destruct()
                cur_node = next_node
        self.destruct()

    #Pre: curr:       currency object to be added
    #     i (int):    index where currency will be added
    #Post: currency object is added to the specified index of the linkedlist
    def addCurrency(self, curr, i):
        c = LinkNode(curr, None)
        if i > self.count:
            raise IndexError("Index out of bounds")
        prevCurrency = SinglyLinkedList.getCurrency(self, i - 1)
        if prevCurrency == None:
            self.start = LinkNode(c.data, self.start)
        else:
            currentCurrency = prevCurrency.next
            prevCurrency.next = c
            c.next = currentCurrency
        self.count += 1

    #Pre: i (int): index where currency should be removed from
    #Post: currency object at the specified index is removed from the linkedlist
    def removeCurrency(self, i):
        if isinstance(i, Currency):
            SinglyLinkedList.removeCurrency(self, SinglyLinkedList.findCurrency(self, i))
            return
        if i >= self.count:
            raise IndexError("Index out of bounds")
        prevCurrency = SinglyLinkedList.getCurrency(self, i - 1)
        curCurrency = prevCurrency.next
        if prevCurrency == None:
            self.start = self.start.next
        else:
            prevCurrency.next = prevCurrency.next.next
        self.count -= 1
        curCurrency.destruct()

    #Pre: c (currency): currency object to be found
    #Post:
    def findCurrency(self, c):
        if self.start == None:
            return -1
        index = 0
        cur = self.start
        while cur != None:
            if cur.data.getValue() == c.getValue():
                return index
            index += 1
            cur = cur.next
        return -1
    
    #Pre: i (int): index where currency object is retrieved from
    #Post: 
    def getCurrency(self, i):
        if self.start == None:
            return None
        index = 0
        c = self.start
        while index < i:
            index += 1
            c = c.next
        return c
    
    def printList(self):
        result = "List: \n"
        if self.start == None:
            return "List is empty"
        else:
            cur = self.start
            while cur != None:
                result += "    " + cur.data.toString() + "\n"
                cur = cur.next
        return result.rstrip()
        
    def isListEmpty(self):
        if self.start == None:
            return True
        
    def countCurrency(self):
        return self.count

        