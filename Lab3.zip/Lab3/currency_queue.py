# Elad Tal and Aditya Gompa
# Lab 03
# The Queue Class is derived from the SinglyLinkedList class and handles a data set of currency objects with no additional attributes and the usual queue methods

from singlylinkedlist import SinglyLinkedList
from currency import Currency 

class Queue(SinglyLinkedList):

#Pre: 
#Post: Queue object with empty linked list
    def __init__(self):
        super().__init__()

#Pre: c (currency) object added to the queue
#Post: c added to the end of the queue
    def enqueue(self, c):
        super().addCurrency(c, super().countCurrency())

#Pre: queue isn't empty
#Post: currency object removed from the front of the queue
    def dequeue(self):
        if self.count == 0:
            raise IndexError("Index out of bounds")
        c = super().getCurrency(0)
        super().removeCurrency(0)
        return c

#Pre: queue isn't empty
#Post:
    def peekFront(self):
        return super().getCurrency(0).data.copy()

#Pre: queue isn't empty
#Post: 
    def peekRear(self):
        return super().getCurrency(super().countCurrency()-1).data.copy()

#Pre:
#Post:
    def printQueue(self):
        result = "Queue: \n"
        cur_node = self.start
        while cur_node != None:
            result += "    " + cur_node.data.toString() + "\n"
            cur_node = cur_node.next
        return result.rstrip()

#Pre: 
#Post: queue is destroyed and memory is deallocated
#Return: 
    def destroyQueue(self):
        super().destroyList()

    def destroyList(self):
        raise NotImplementedError("Stack does not support destroyList")

    def addCurrency(self, c, i):
        raise NotImplementedError("Stack does not support addCurrency")

    def removeCurrency(self, i):
        raise NotImplementedError("Stack does not support removeCurrency")

    def findCurrency(self, c):
        raise NotImplementedError("Stack does not support findCurrency")
        
    def getCurrency(self, i):
        raise NotImplementedError("Stack does not support getCurrency")
        
    def printList(self):
        raise NotImplementedError("Stack does not support printList")
        
    def isListEmpty(self):
        raise NotImplementedError("Stack does not support isListEmpty")
        
    def countCurrency(self):
        raise NotImplementedError("Stack does not support countCurrency")